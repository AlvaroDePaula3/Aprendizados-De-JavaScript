import { useState } from 'react'
import reactLogo from './assets/react.svg'
import './App.css'
import Tarefa from './components/Tarefa'

function App() {
  const [count, setCount] = useState(0)

  return (
    <div className="App">
      <Tarefa/>
    </div>
  )
}

export default App
