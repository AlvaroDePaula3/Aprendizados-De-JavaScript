
import React, { useState } from 'react';
import thommy from './images/thommy.jpg';

function Tarefa({titulo = "Qualquer Título" }) {

  const [valorInput, setValorInput] = useState(false);

  return (
    <div>
      <label onClick={() => setValorInput(!valorInput)}>{titulo}</label>
      <input checked={valorInput} type= 'checkbox'></input>
      <img height="450px" src={thommy} alt="É literalmente o thommy shelby com a camisa do flamengo"></img>
    </div>
  )
}

export default Tarefa